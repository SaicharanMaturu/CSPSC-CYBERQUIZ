



const easyQuestions = [
  {
    question: "What is phishing?",
    options: ["A type of fishing", "A scam to steal personal information", "A security feature", "A way to catch viruses"],
    answer: "A scam to steal personal information",
    explanation: "Phishing is a common scam where cybercriminals trick people into giving personal or financial information through fake emails or websites."
  },
  {
    question: "What should you do if you receive an email asking for your password?",
    options: ["Ignore it", "Reply with your password", "Report it", "Delete it"],
    answer: "Report it",
    explanation: "Legitimate organizations will never ask for your password via email. If you receive such an email, report it as phishing."
  },
  {
    question: "What is a strong password?",
    options: ["Your birthday", "A mix of letters, numbers, and symbols", "Your pet's name", "123456"],
    answer: "A mix of letters, numbers, and symbols",
    explanation: "A strong password should include a mix of uppercase, lowercase letters, numbers, and special characters to prevent easy guessing."
  },
  {
    question: "What is two-factor authentication (2FA)?",
    options: ["A new phone", "A type of scam", "An extra layer of security", "A kind of virus"],
    answer: "An extra layer of security",
    explanation: "Two-factor authentication adds an additional layer of security by requiring something you know (password) and something you have (like a phone) to access your account."
  },
  {
    question: "Should you click on links from unknown emails?",
    options: ["Yes", "Only if they look important", "No", "Only from friends"],
    answer: "No",
    explanation: "Clicking on links from unknown emails can lead to phishing sites or malware downloads. Always verify the sender."
  },
  {
    question: "What should you do if you receive a suspicious text message from your bank?",
    options: ["Click the link", "Reply with your account number", "Call your bank directly", "Ignore it"],
    answer: "Call your bank directly",
    explanation: "If you receive a suspicious text or email, don’t click any links. Instead, call your bank directly using their official contact number."
  },
  {
    question: "What is a pop-up ad?",
    options: ["A scam", "An ad that opens in a new window", "An error message", "A security feature"],
    answer: "An ad that opens in a new window",
    explanation: "Pop-up ads are windows that appear on your screen, often used for advertising, but sometimes they can carry malware."
  },
  {
    question: "What should you do if a website asks for personal information?",
    options: ["Give it", "Check if it's secure (https)", "Ignore it", "Call your friend"],
    answer: "Check if it's secure (https)",
    explanation: "Before providing personal information, ensure the website is secure by checking for 'https' in the URL."
  },
  {
    question: "What is an antivirus software used for?",
    options: ["To speed up your computer", "To protect against viruses and malware", "To download games", "To update your system"],
    answer: "To protect against viruses and malware",
    explanation: "Antivirus software helps detect and prevent malware and viruses from infecting your computer."
  },
  {
    question: "Should you share your Social Security number online?",
    options: ["Yes", "Only with trusted websites", "Only with family", "No"],
    answer: "No",
    explanation: "Your Social Security number should never be shared online. It can be used to steal your identity."
  },
  {
    question: "What does the 'S' in 'HTTPS' stand for?",
    options: ["Secure", "Simple", "Smart", "Safe"],
    answer: "Secure",
    explanation: "The 'S' in HTTPS stands for 'Secure', indicating that the website uses encryption to protect your data."
  },
  {
    question: "Should you open attachments from unknown emails?",
    options: ["Yes", "Only if they look important", "No", "Sometimes"],
    answer: "No",
    explanation: "Attachments in unknown emails may contain malware. It’s best not to open them unless you are sure of the sender."
  },
  {
    question: "What is a scammer likely to ask for in a phishing email?",
    options: ["Your password", "Your favorite color", "Your age", "Your last vacation spot"],
    answer: "Your password",
    explanation: "Phishing emails often try to trick you into giving sensitive information like passwords or credit card numbers."
  },
  {
    question: "What is malware?",
    options: ["A type of hardware", "A virus that harms your computer", "A password manager", "An email attachment"],
    answer: "A virus that harms your computer",
    explanation: "Malware is any software designed to harm your computer or steal your data."
  },
  {
    question: "What should you do if your computer is acting strange?",
    options: ["Ignore it", "Download more software", "Run a virus scan", "Turn it off"],
    answer: "Run a virus scan",
    explanation: "If your computer is acting strange, it might be infected with malware. Run a virus scan to detect and remove any threats."
  },
  {
    question: "What should you do if a website looks suspicious?",
    options: ["Leave the site immediately", "Click all the links", "Download files from it", "Trust it"],
    answer: "Leave the site immediately",
    explanation: "If a website looks suspicious, it's best to close the window to avoid any risk of scams or malware."
  },
  {
    question: "What is identity theft?",
    options: ["When someone pretends to be you", "When your email is hacked", "A type of phishing", "A virus"],
    answer: "When someone pretends to be you",
    explanation: "Identity theft occurs when someone uses your personal information to impersonate you, often to commit fraud."
  },
  {
    question: "Should you use the same password for all your accounts?",
    options: ["Yes", "No", "Only for social media", "Only for shopping accounts"],
    answer: "No",
    explanation: "Using the same password across accounts increases the risk of all your accounts being compromised if one is hacked."
  },
  {
    question: "What should you do if someone calls claiming to be from tech support and asks for access to your computer?",
    options: ["Let them in", "Hang up", "Give them access", "Ask them to call back"],
    answer: "Hang up",
    explanation: "Legitimate companies won't ask for access to your computer over the phone. Hang up and report the call."
  },
  {
    question: "What is ransomware?",
    options: ["A type of phishing scam", "A scam where your data is held hostage", "A virus", "A security update"],
    answer: "A scam where your data is held hostage",
    explanation: "Ransomware is a type of malware that locks your files until you pay a ransom to the attacker."
  },
  {
    question: "What is ransomware?",
    options: ["A type of phishing scam", "A scam where your data is held hostage", "A virus", "A security update"],
    answer: "A scam where your data is held hostage",
    explanation: "Ransomware is a type of malware that locks your files until you pay a ransom to the attacker."
  },
  {
    question: "What is a firewall?",
    options: ["A type of virus", "A physical barrier", "A security feature that blocks unauthorized access", "A type of malware"],
    answer: "A security feature that blocks unauthorized access",
    explanation: "A firewall is a security system that monitors and controls incoming and outgoing network traffic based on predetermined security rules."
  },
  {
    question: "What is a secure website indicated by in the URL?",
    options: ["http://", "https://", "ftp://", "file://"],
    answer: "https://",
    explanation: "A secure website is indicated by 'https://' in the URL, which means it uses encryption to protect data."
  },
  {
    question: "What is a common sign of a phishing email?",
    options: ["Correct spelling and grammar", "A personalized greeting", "Urgent requests for personal information", "A recognizable sender's email address"],
    answer: "Urgent requests for personal information",
    explanation: "Phishing emails often have urgent requests for personal information, such as passwords or credit card numbers."
  },
  {
    question: "What should you use to create a unique and strong password?",
    options: ["A common word", "Your name", "A mix of letters, numbers, and special characters", "A sequence of numbers"],
    answer: "A mix of letters, numbers, and special characters",
    explanation: "A strong password should be a mix of letters, numbers, and special characters to ensure it is difficult to guess."
  },
  {
    question: "What is malware?",
    options: ["A security update", "A type of antivirus", "Software designed to harm your computer", "A password manager"],
    answer: "Software designed to harm your computer",
    explanation: "Malware is malicious software designed to damage or disrupt your computer or steal information."
  },
  {
    question: "What should you do if you receive a suspicious phone call asking for personal information?",
    options: ["Give them the information", "Hang up and verify with the company", "Ask for their email address", "Call them back later"],
    answer: "Hang up and verify with the company",
    explanation: "If you receive a suspicious call, hang up and contact the company directly using their official contact information to verify the call."
  },
  {
    question: "What is a VPN used for?",
    options: ["To speed up your internet connection", "To hide your online activity and secure your connection", "To update your browser", "To scan for viruses"],
    answer: "To hide your online activity and secure your connection",
    explanation: "A VPN (Virtual Private Network) helps protect your online privacy by encrypting your internet connection and hiding your activity."
  },
  {
    question: "What is a common sign that a website is not secure?",
    options: ["It has a padlock icon", "It uses 'https://' in the URL", "It asks for personal information without encryption", "It has a green address bar"],
    answer: "It asks for personal information without encryption",
    explanation: "A website that requests personal information without using encryption ('https://') is not secure and could be a scam."
  },
  {
    question: "What should you do if you think your account has been compromised?",
    options: ["Change your password immediately", "Ignore it", "Ask a friend for help", "Wait for a week"],
    answer: "Change your password immediately",
    explanation: "If you suspect your account has been compromised, change your password right away and monitor your account for unusual activity."
  }
];
const mediumQuestions = [
  {
    question: "What is a two-factor authentication (2FA)?",
    options: ["A type of password", "A security measure requiring two forms of verification", "A software update", "A type of encryption"],
    answer: "A security measure requiring two forms of verification",
    explanation: "Two-factor authentication (2FA) adds an extra layer of security by requiring a second form of verification in addition to your password."
  },
  {
    question: "What does HTTPS stand for?",
    options: ["HyperText Transfer Protocol Secure", "HyperText Transfer Protocol Standard", "High Transfer Protocol Security", "High Text Transfer Protocol Secure"],
    answer: "HyperText Transfer Protocol Secure",
    explanation: "HTTPS stands for HyperText Transfer Protocol Secure and indicates that the data exchanged between your browser and the website is encrypted."
  },
  {
    question: "What is social engineering in the context of cyber scams?",
    options: ["A type of computer virus", "Tricking people into revealing personal information", "A form of encryption", "A method to speed up internet connection"],
    answer: "Tricking people into revealing personal information",
    explanation: "Social engineering involves manipulating individuals into divulging confidential information by exploiting psychological or emotional factors."
  },
  {
    question: "What is a common method used by scammers to gain access to your personal information?",
    options: ["Phishing emails", "Updating software", "Using secure websites", "Scanning for viruses"],
    answer: "Phishing emails",
    explanation: "Scammers often use phishing emails to trick individuals into providing sensitive information by pretending to be a trusted source."
  },
  {
    question: "What is the purpose of antivirus software?",
    options: ["To prevent physical damage to your computer", "To scan for and remove malicious software", "To speed up your computer", "To update your operating system"],
    answer: "To scan for and remove malicious software",
    explanation: "Antivirus software helps protect your computer by detecting, blocking, and removing malicious software such as viruses and malware."
  },
  {
    question: "What does the term 'malware' refer to?",
    options: ["Software designed to help with productivity", "Software designed to harm or exploit your computer", "A type of internet connection", "A web browser feature"],
    answer: "Software designed to harm or exploit your computer",
    explanation: "Malware is a broad term for any software designed to damage, disrupt, or gain unauthorized access to computer systems."
  },
  {
    question: "What is a common sign of a fraudulent email?",
    options: ["A professional email signature", "A request for urgent action or payment", "A clear and concise message", "A familiar sender's email address"],
    answer: "A request for urgent action or payment",
    explanation: "Fraudulent emails often create a sense of urgency or pressure you into making a payment or providing personal information quickly."
  },
  {
    question: "What should you do before clicking on a link in an email?",
    options: ["Verify the sender's email address", "Click on the link immediately", "Reply to the email", "Ignore it"],
    answer: "Verify the sender's email address",
    explanation: "Before clicking on a link in an email, verify that the sender's email address is legitimate and not a spoofed or phishing attempt."
  },
  {
    question: "What is identity theft?",
    options: ["Losing your password", "Someone using your personal information without permission", "A type of computer virus", "A method to recover lost data"],
    answer: "Someone using your personal information without permission",
    explanation: "Identity theft occurs when someone uses your personal information, such as Social Security numbers or credit card details, without your consent to commit fraud."
  },
  {
    question: "What is a common precaution to take when using public Wi-Fi?",
    options: ["Use a VPN", "Access sensitive accounts", "Disable antivirus software", "Share your network connection"],
    answer: "Use a VPN",
    explanation: "Using a VPN (Virtual Private Network) helps protect your data and privacy when connecting to public Wi-Fi by encrypting your internet traffic."
  },
  {
    question: "What is the primary purpose of a password manager?",
    options: ["To store and encrypt passwords securely", "To monitor your internet usage", "To update your operating system", "To block spam emails"],
    answer: "To store and encrypt passwords securely",
    explanation: "A password manager securely stores and encrypts your passwords, making it easier to manage and use strong, unique passwords for different accounts."
  },
  {
    question: "What is a firewall used for?",
    options: ["To block unauthorized access to a network", "To speed up internet connection", "To manage email traffic", "To scan for malware"],
    answer: "To block unauthorized access to a network",
    explanation: "A firewall helps protect a network by filtering incoming and outgoing traffic to block unauthorized access."
  },
  {
    question: "What does the term 'phishing' refer to?",
    options: ["A type of malware", "A technique to steal sensitive information through deceptive emails or websites", "A method to improve internet speed", "A tool for managing passwords"],
    answer: "A technique to steal sensitive information through deceptive emails or websites",
    explanation: "Phishing is a scam where attackers use deceptive emails or websites to trick individuals into revealing sensitive information."
  },
  {
    question: "What is the purpose of software updates?",
    options: ["To fix security vulnerabilities and bugs", "To change the color scheme", "To speed up the computer", "To add new features only"],
    answer: "To fix security vulnerabilities and bugs",
    explanation: "Software updates often include patches that fix security vulnerabilities and bugs, helping to protect your system from threats."
  },
  {
    question: "What does 'spam' refer to in the context of emails?",
    options: ["Unsolicited or junk emails", "Emails from trusted sources", "Emails with attachments", "Emails with attachments from known contacts"],
    answer: "Unsolicited or junk emails",
    explanation: "Spam refers to unwanted or unsolicited emails, often sent in bulk, that may contain advertisements or malicious content."
  },
  {
    question: "What is the purpose of encryption?",
    options: ["To protect data by converting it into a secure format", "To speed up data transfer", "To change the appearance of data", "To organize files"],
    answer: "To protect data by converting it into a secure format",
    explanation: "Encryption converts data into a secure format that can only be read by someone with the correct decryption key, protecting it from unauthorized access."
  },
  {
    question: "What is a VPN and how does it protect your data?",
    options: ["Virtual Private Network; it encrypts your internet traffic", "Virtual Public Network; it manages internet speed", "Virtual Protected Network; it blocks ads", "Virtual Privacy Network; it stores your passwords"],
    answer: "Virtual Private Network; it encrypts your internet traffic",
    explanation: "A VPN (Virtual Private Network) encrypts your internet traffic and masks your IP address, protecting your data and privacy when online."
  },
  {
    question: "What is a common sign that a website is secure?",
    options: ["The URL starts with 'http://'", "The URL starts with 'https://'", "The website has a colorful design", "The website is popular"],
    answer: "The URL starts with 'https://'",
    explanation: "Websites with URLs starting with 'https://' use secure protocols to encrypt data exchanged between your browser and the site."
  },
  {
    question: "What should you do if you receive a suspicious email from a bank asking for your account details?",
    options: ["Ignore the email", "Forward it to your bank's fraud department", "Click on the provided link to verify", "Reply with your account details"],
    answer: "Forward it to your bank's fraud department",
    explanation: "Suspicious emails should be forwarded to your bank's fraud department rather than interacting with them to avoid falling for phishing scams."
  },
  {
    question: "What does 'social engineering' refer to in cybersecurity?",
    options: ["A method of securing physical locations", "Tricking people into divulging confidential information", "A technique for coding software", "A way to manage network traffic"],
    answer: "Tricking people into divulging confidential information",
    explanation: "Social engineering exploits human psychology to trick individuals into revealing confidential information or performing actions that compromise security."
  },
  {
    question: "What is the main purpose of a security patch?",
    options: ["To fix vulnerabilities in software", "To change the software interface", "To add new features", "To improve internet speed"],
    answer: "To fix vulnerabilities in software",
    explanation: "A security patch addresses and fixes vulnerabilities in software, helping to protect it from potential threats and exploits."
  },
  {
    question: "What is a 'brute-force attack'?",
    options: ["A method of guessing passwords by trying many combinations", "A type of virus", "A way to speed up internet connections", "A method for data encryption"],
    answer: "A method of guessing passwords by trying many combinations",
    explanation: "A brute-force attack involves trying numerous password combinations until the correct one is found, often used to crack weak passwords."
  },
  {
    question: "What is 'phishing' often disguised as?",
    options: ["Official communications from trusted organizations", "A random advertisement", "A pop-up ad", "An error message"],
    answer: "Official communications from trusted organizations",
    explanation: "Phishing attempts are often disguised as official communications from trusted organizations to trick individuals into providing sensitive information."
  },
  {
    question: "What does 'malware' stand for?",
    options: ["Malicious software", "Managed software", "Maintenance software", "Multipurpose software"],
    answer: "Malicious software",
    explanation: "Malware is short for malicious software, designed to harm or exploit computer systems and data."
  },
  {
    question: "What is a 'spyware'?",
    options: ["Software designed to monitor and collect user information without consent", "A type of security software", "A software update tool", "A game application"],
    answer: "Software designed to monitor and collect user information without consent",
    explanation: "Spyware secretly monitors and collects information about users without their consent, often used for malicious purposes."
  },
  {
    question: "What is 'identity theft'?",
    options: ["Stealing someone's identity for fraudulent purposes", "Losing access to a social media account", "Misplacing a password", "A type of computer virus"],
    answer: "Stealing someone's identity for fraudulent purposes",
    explanation: "Identity theft involves using someone else's personal information, such as Social Security numbers or credit card details, to commit fraud."
  },
  {
    question: "What is a 'botnet'?",
    options: ["A network of infected computers controlled by an attacker", "A type of internet connection", "A software tool for securing networks", "A form of encryption"],
    answer: "A network of infected computers controlled by an attacker",
    explanation: "A botnet is a network of computers infected with malware and controlled remotely by an attacker, often used to carry out large-scale cyberattacks."
  },
  {
    question: "What is 'ransomware'?",
    options: ["A type of phishing scam", "A scam where your data is held hostage", "A virus", "A security update"],
    answer: "A scam where your data is held hostage",
    explanation: "Ransomware is a type of malware that locks your files until you pay a ransom to the attacker."
  },
  {
    question: "What does 'anti-virus software' do?",
    options: ["Detects and removes malicious software", "Enhances computer speed", "Updates operating systems", "Manages email accounts"],
    answer: "Detects and removes malicious software",
    explanation: "Anti-virus software helps detect, block, and remove malicious software, including viruses, to protect your computer and data."
  },
  {
    question: "What is a 'phishing scam'?",
    options: ["A fraudulent attempt to obtain sensitive information by disguising as a trustworthy entity", "A method to speed up internet connections", "A type of encryption", "A tool for data recovery"],
    answer: "A fraudulent attempt to obtain sensitive information by disguising as a trustworthy entity",
    explanation: "Phishing scams trick individuals into revealing sensitive information by pretending to be a trustworthy source, often through deceptive emails or websites."
  },
  {
    question: "What does 'HTTPS' stand for in web addresses?",
    options: ["HyperText Transfer Protocol Secure", "HyperText Transfer Protocol Standard", "High Transfer Protocol Secure", "High Text Transfer Protocol Secure"],
    answer: "HyperText Transfer Protocol Secure",
    explanation: "HTTPS stands for HyperText Transfer Protocol Secure, indicating that the website uses encryption to protect data transmitted between your browser and the site."
  },
  {
    question: "What is a 'cyber attack'?",
    options: ["An attempt to damage or disrupt a computer system", "A software update", "A form of network management", "A type of computer virus"],
    answer: "An attempt to damage or disrupt a computer system",
    explanation: "A cyber attack is a deliberate attempt to damage, disrupt, or gain unauthorized access to a computer system or network."
  },
  {
    question: "What is a 'data breach'?",
    options: ["Unauthorized access to confidential information", "A software malfunction", "A type of computer virus", "An internet speed issue"],
    answer: "Unauthorized access to confidential information",
    explanation: "A data breach occurs when unauthorized individuals gain access to confidential or sensitive information, often leading to data loss or theft."
  },
  {
    question: "What is the role of a 'cybersecurity firewall'?",
    options: ["To filter and block unauthorized network traffic", "To manage email communications", "To speed up internet access", "To encrypt data"],
    answer: "To filter and block unauthorized network traffic",
    explanation: "A cybersecurity firewall filters network traffic to block unauthorized access and protect systems from potential threats."
  },
  {
    question: "What is 'identity verification' in the context of online security?",
    options: ["Confirming the identity of a user through various methods", "Changing a password", "Encrypting data", "Scanning for malware"],
    answer: "Confirming the identity of a user through various methods",
    explanation: "Identity verification involves confirming a user's identity through methods such as passwords, biometric data, or security questions to ensure secure access."
  },
  {
    question: "What is 'malware'?",
    options: ["Malicious software designed to harm or exploit computer systems", "A type of antivirus program", "A method to increase internet speed", "A software update tool"],
    answer: "Malicious software designed to harm or exploit computer systems",
    explanation: "Malware refers to malicious software created to damage, disrupt, or gain unauthorized access to computer systems and data."
  },
  {
    question: "What is a 'secure password'?",
    options: ["A password that is difficult to guess and contains a mix of characters", "A simple word or phrase", "A password used for multiple accounts", "A common word or name"],
    answer: "A password that is difficult to guess and contains a mix of characters",
    explanation: "A secure password is complex, including a mix of letters, numbers, and special characters, making it difficult for attackers to guess or crack."
  }
];
const hardQuestions = [
  {
    question: "What is a 'zero-day exploit'?",
    options: ["A vulnerability that has no known fix at the time of discovery", "A type of encryption algorithm", "A software update issued on the day it is discovered", "A malware designed to work on the day of its release"],
    answer: "A vulnerability that has no known fix at the time of discovery",
    explanation: "A zero-day exploit targets a vulnerability that is unknown to the software vendor and has no fix at the time of discovery, making it especially dangerous."
  },
  {
    question: "What is the main goal of a 'Denial-of-Service (DoS) attack'?",
    options: ["To overwhelm a system and disrupt its normal function", "To steal data from a network", "To encrypt user files", "To gain unauthorized access to a system"],
    answer: "To overwhelm a system and disrupt its normal function",
    explanation: "A Denial-of-Service (DoS) attack aims to overwhelm a system with excessive requests, rendering it unavailable to legitimate users."
  },
  {
    question: "What does 'social engineering' in cybersecurity typically involve?",
    options: ["Manipulating individuals into revealing confidential information", "Analyzing system vulnerabilities", "Encrypting sensitive data", "Developing security patches"],
    answer: "Manipulating individuals into revealing confidential information",
    explanation: "Social engineering involves manipulating people into disclosing confidential information or performing actions that compromise security."
  },
  {
    question: "What is 'malvertising'?",
    options: ["Malicious advertising that infects systems through ads", "A method of encrypting data", "An online advertisement for security software", "A type of phishing scam"],
    answer: "Malicious advertising that infects systems through ads",
    explanation: "Malvertising involves malicious ads that, when clicked or viewed, can deliver malware to the user's system."
  },
  {
    question: "What is 'DNS spoofing'?",
    options: ["Redirecting users to fraudulent websites by corrupting DNS records", "A method for speeding up internet connections", "A technique for encrypting data", "A type of firewall attack"],
    answer: "Redirecting users to fraudulent websites by corrupting DNS records",
    explanation: "DNS spoofing involves corrupting DNS records to redirect users to fraudulent websites, often used to steal sensitive information."
  },
  {
    question: "What does 'cross-site scripting (XSS)' refer to?",
    options: ["Injecting malicious scripts into web pages viewed by other users", "A method of encrypting web traffic", "A technique for managing web servers", "A type of phishing attack"],
    answer: "Injecting malicious scripts into web pages viewed by other users",
    explanation: "Cross-site scripting (XSS) involves injecting malicious scripts into web pages, which are then executed in the browsers of other users, potentially stealing data or causing harm."
  },
  {
    question: "What is 'SQL injection'?",
    options: ["A technique used to manipulate database queries through malicious input", "A method for securing SQL databases", "A type of firewall attack", "A tool for analyzing web traffic"],
    answer: "A technique used to manipulate database queries through malicious input",
    explanation: "SQL injection is a technique that exploits vulnerabilities in database queries by injecting malicious SQL code, allowing attackers to access or manipulate data."
  },
  {
    question: "What does 'buffer overflow' refer to in cybersecurity?",
    options: ["An attack that overwrites the memory of a program to execute malicious code", "A method of data encryption", "A type of network intrusion", "A technique for data compression"],
    answer: "An attack that overwrites the memory of a program to execute malicious code",
    explanation: "A buffer overflow occurs when more data is written to a buffer than it can hold, potentially overwriting adjacent memory and executing malicious code."
  },
  {
    question: "What is 'Man-in-the-Middle (MitM) attack'?",
    options: ["An attack where the attacker intercepts and potentially alters communication between two parties", "A method for encrypting data", "A type of phishing scam", "A technique for managing network traffic"],
    answer: "An attack where the attacker intercepts and potentially alters communication between two parties",
    explanation: "In a Man-in-the-Middle (MitM) attack, the attacker intercepts and possibly alters the communication between two parties, allowing them to eavesdrop or manipulate the data exchanged."
  },
  {
    question: "What is 'cryptojacking'?",
    options: ["Using a victim's computing resources to mine cryptocurrency without their knowledge", "A type of ransomware", "A method for securing cryptocurrency wallets", "A tool for encrypting data"],
    answer: "Using a victim's computing resources to mine cryptocurrency without their knowledge",
    explanation: "Cryptojacking involves using a victim's computer resources to mine cryptocurrency secretly, often through malicious software or compromised websites."
  },
  {
    question: "What does 'two-factor authentication (2FA)' involve?",
    options: ["Requiring two forms of verification to access an account", "Encrypting data with two different algorithms", "Using two passwords for security", "A method of monitoring network traffic"],
    answer: "Requiring two forms of verification to access an account",
    explanation: "Two-factor authentication (2FA) adds an extra layer of security by requiring two forms of verification, such as a password and a code sent to your phone."
  },
  {
    question: "What is 'zero trust security'?",
    options: ["A security model where no entity is trusted by default, and verification is required continuously", "A method for encrypting zero-day exploits", "A security measure for trusted networks", "A type of firewall"],
    answer: "A security model where no entity is trusted by default, and verification is required continuously",
    explanation: "Zero trust security operates on the principle that no entity, whether inside or outside the network, should be trusted by default, and continuous verification is necessary."
  },
  {
    question: "What is a 'rootkit'?",
    options: ["Malware designed to gain unauthorized access and maintain control over a system without detection", "A type of encryption tool", "A method for securing networks", "A type of firewall"],
    answer: "Malware designed to gain unauthorized access and maintain control over a system without detection",
    explanation: "A rootkit is a type of malware that provides unauthorized access and control over a system while avoiding detection by users and security software."
  },
  {
    question: "What is 'DNS hijacking'?",
    options: ["Redirecting users from legitimate DNS queries to malicious sites", "A method for managing DNS servers", "A technique for encrypting DNS traffic", "A tool for monitoring DNS requests"],
    answer: "Redirecting users from legitimate DNS queries to malicious sites",
    explanation: "DNS hijacking involves redirecting legitimate DNS queries to malicious sites, which can lead to phishing, data theft, or other attacks."
  },
  {
    question: "What does 'privilege escalation' mean?",
    options: ["Gaining higher levels of access or permissions on a system than intended", "A method for encrypting files", "A technique for securing network traffic", "A type of password attack"],
    answer: "Gaining higher levels of access or permissions on a system than intended",
    explanation: "Privilege escalation occurs when an attacker gains higher access levels or permissions on a system, often exploiting vulnerabilities or misconfigurations."
  },
  {
    question: "What is a 'watering hole attack'?",
    options: ["A targeted attack where the attacker infects a commonly visited site to target specific users", "A method of encrypting website data", "A type of phishing scam", "A technique for blocking malicious traffic"],
    answer: "A targeted attack where the attacker infects a commonly visited site to target specific users",
    explanation: "In a watering hole attack, the attacker infects a site that is frequently visited by the target audience, aiming to compromise the visitors' systems."
  },
  {
    question: "What is 'code injection'?",
    options: ["Inserting malicious code into a program to manipulate its behavior", "A method for securing software", "A type of encryption", "A technique for managing system updates"],
    answer: "Inserting malicious code into a program to manipulate its behavior",
    explanation: "Code injection involves inserting malicious code into a program or system, which can manipulate its behavior and potentially compromise security."
  },
  {
    question: "What does 'end-to-end encryption' ensure?",
    options: ["Data is encrypted on the sender's side and decrypted only on the recipient's side", "Data is encrypted during transmission only", "Data is encrypted at rest", "Data is encrypted in transit and at rest"],
    answer: "Data is encrypted on the sender's side and decrypted only on the recipient's side",
    explanation: "End-to-end encryption ensures that data is encrypted by the sender and only decrypted by the recipient, preventing unauthorized access during transmission."
  },
  {
    question: "What is 'advanced persistent threat (APT)'?",
    options: ["A prolonged and targeted cyberattack by a sophisticated adversary", "A method for protecting against malware", "A type of network intrusion", "A security update tool"],
    answer: "A prolonged and targeted cyberattack by a sophisticated adversary",
    explanation: "An advanced persistent threat (APT) is a long-term, targeted cyberattack conducted by a sophisticated adversary aiming to steal sensitive information."
  },
  {
    question: "What is 'behavioral analysis' in cybersecurity?",
    options: ["Monitoring and analyzing user behavior to detect anomalies or threats", "A method for encrypting user data", "A type of firewall rule", "A technique for managing network traffic"],
    answer: "Monitoring and analyzing user behavior to detect anomalies or threats",
    explanation: "Behavioral analysis involves observing and analyzing user behavior patterns to detect any unusual or potentially malicious activities."
  },
  {
    question: "What is 'data exfiltration'?",
    options: ["The unauthorized transfer of data from a system", "A method for securing data transmissions", "A type of malware", "A technique for encrypting files"],
    answer: "The unauthorized transfer of data from a system",
    explanation: "Data exfiltration refers to the unauthorized transfer of sensitive data from a system, often performed by attackers to steal information."
  },
  {
    question: "What is 'sandboxing' in cybersecurity?",
    options: ["Running potentially untrusted code in an isolated environment to prevent harm to the system", "A method for encrypting data", "A type of network monitoring", "A technique for managing system updates"],
    answer: "Running potentially untrusted code in an isolated environment to prevent harm to the system",
    explanation: "Sandboxing involves executing untrusted code or applications in an isolated environment, preventing potential damage or interference with the main system."
  },
  {
    question: "What does 'cryptographic hashing' do?",
    options: ["Transforms data into a fixed-size hash value to ensure integrity and authenticity", "Encrypts data for secure transmission", "Decrypts encoded information", "Manages user authentication processes"],
    answer: "Transforms data into a fixed-size hash value to ensure integrity and authenticity",
    explanation: "Cryptographic hashing converts data into a fixed-size hash value, which can be used to verify data integrity and authenticity without exposing the original data."
  },
  {
    question: "What is a 'security information and event management (SIEM) system'?",
    options: ["A system that collects, analyzes, and monitors security data from various sources", "A type of malware detection tool", "A method for encrypting network traffic", "A type of firewall"],
    answer: "A system that collects, analyzes, and monitors security data from various sources",
    explanation: "A security information and event management (SIEM) system aggregates and analyzes security data from various sources to detect and respond to potential threats."
  },
  {
    question: "What does 'vulnerability scanning' involve?",
    options: ["Scanning systems for weaknesses that could be exploited by attackers", "Encrypting data to protect against breaches", "A method for managing network traffic", "A type of password attack"],
    answer: "Scanning systems for weaknesses that could be exploited by attackers",
    explanation: "Vulnerability scanning involves identifying and assessing weaknesses in systems that could be exploited by attackers, helping to address potential security risks."
  },
  {
    question: "What is 'data masking'?",
    options: ["Obscuring sensitive data to protect it from unauthorized access", "Encrypting data for secure storage", "A method for managing network traffic", "A type of security patch"],
    answer: "Obscuring sensitive data to protect it from unauthorized access",
    explanation: "Data masking involves obscuring or altering sensitive data to protect it from unauthorized access while retaining its usability for legitimate purposes."
  },
  {
    question: "What is 'network segmentation'?",
    options: ["Dividing a network into smaller segments to enhance security and manage traffic", "Encrypting network data", "A method for managing user access", "A type of firewall"],
    answer: "Dividing a network into smaller segments to enhance security and manage traffic",
    explanation: "Network segmentation involves dividing a network into smaller segments to improve security, control traffic, and limit the impact of potential breaches."
  },
  {
    question: "What does 'attack surface' refer to?",
    options: ["The total area of a system that is exposed to potential attacks", "A type of firewall protection", "A method for securing network traffic", "A type of encryption algorithm"],
    answer: "The total area of a system that is exposed to potential attacks",
    explanation: "The attack surface is the sum of all possible points where an attacker could attempt to breach or exploit a system."
  },
  {
    question: "What is 'public key infrastructure (PKI)'?",
    options: ["A framework for managing digital certificates and encryption keys", "A type of firewall", "A method for managing network traffic", "A type of phishing attack"],
    answer: "A framework for managing digital certificates and encryption keys",
    explanation: "Public key infrastructure (PKI) is a system for managing digital certificates and encryption keys, enabling secure communication and data protection."
  },
  {
    question: "What is 'insider threat'?",
    options: ["A security risk posed by individuals within the organization", "A type of external attack", "A method for encrypting sensitive data", "A type of phishing scam"],
    answer: "A security risk posed by individuals within the organization",
    explanation: "An insider threat refers to a security risk posed by individuals within an organization who may misuse their access to compromise data or systems."
  },
  {
    question: "What is 'ransomware-as-a-service (RaaS)'?",
    options: ["A model where ransomware is sold or rented out to other criminals", "A method for protecting against ransomware", "A type of antivirus program", "A technique for encrypting data"],
    answer: "A model where ransomware is sold or rented out to other criminals",
    explanation: "Ransomware-as-a-Service (RaaS) is a business model where ransomware is offered as a service to other criminals, who can use it to launch their attacks."
  },
  {
    question: "What is 'advanced malware'?",
    options: ["Sophisticated malware that uses various techniques to avoid detection and achieve its objectives", "A type of antivirus software", "A method for securing network traffic", "A type of encryption"],
    answer: "Sophisticated malware that uses various techniques to avoid detection and achieve its objectives",
    explanation: "Advanced malware employs sophisticated techniques to evade detection and accomplish its goals, often involving complex and persistent attacks."
  },
  {
    question: "What is 'email spoofing'?",
    options: ["Sending emails with a forged sender address to deceive recipients", "A method for encrypting email content", "A type of email filtering", "A technique for managing email traffic"],
    answer: "Sending emails with a forged sender address to deceive recipients",
    explanation: "Email spoofing involves falsifying the sender address in an email to deceive the recipient and potentially carry out phishing or other malicious activities."
  },
  {
    question: "What is 'data breach notification'?",
    options: ["The process of informing affected individuals and entities about a data breach", "A method for encrypting data", "A type of network security measure", "A technique for managing user authentication"],
    answer: "The process of informing affected individuals and entities about a data breach",
    explanation: "Data breach notification involves informing affected individuals and organizations about a breach of sensitive data, helping them take appropriate actions to mitigate risks."
  },
  {
    question: "What does 'security posture' refer to?",
    options: ["The overall security status and measures in place to protect an organization", "A type of firewall protection", "A method for encrypting data", "A technique for managing network traffic"],
    answer: "The overall security status and measures in place to protect an organization",
    explanation: "Security posture refers to the collective measures, practices, and status of an organization's security efforts to protect against and respond to potential threats."
  },
  {
    question: "What is 'ethical hacking'?",
    options: ["Legitimate testing of systems to identify and fix security vulnerabilities", "A type of malware", "A method for encrypting data", "A type of phishing attack"],
    answer: "Legitimate testing of systems to identify and fix security vulnerabilities",
    explanation: "Ethical hacking involves authorized testing of systems to find and address security vulnerabilities before malicious hackers can exploit them."
  },
  {
    question: "What is 'risk assessment' in cybersecurity?",
    options: ["The process of identifying and evaluating potential security risks and their impact", "A method for encrypting data", "A type of firewall rule", "A technique for managing network traffic"],
    answer: "The process of identifying and evaluating potential security risks and their impact",
    explanation: "Risk assessment involves identifying and evaluating potential security risks to determine their impact and likelihood, helping organizations prioritize their security measures."
  },
  {
    question: "What does 'data integrity' mean?",
    options: ["Ensuring that data remains accurate, consistent, and unaltered during storage or transmission", "A type of encryption", "A method for managing network traffic", "A technique for user authentication"],
    answer: "Ensuring that data remains accurate, consistent, and unaltered during storage or transmission",
    explanation: "Data integrity ensures that information remains accurate, consistent, and free from unauthorized alterations during storage, processing, and transmission."
  },
  {
    question: "What is 'penetration testing'?",
    options: ["Simulating attacks on a system to identify and address security weaknesses", "A type of malware detection", "A method for encrypting data", "A technique for managing network traffic"],
    answer: "Simulating attacks on a system to identify and address security weaknesses",
    explanation: "Penetration testing involves simulating attacks on a system to discover and fix security vulnerabilities before real attackers can exploit them."
  },
  {
    question: "What is 'data loss prevention (DLP)'?",
    options: ["Strategies and tools to prevent unauthorized access, use, or loss of sensitive data", "A type of firewall protection", "A method for encrypting data", "A technique for managing network traffic"],
    answer: "Strategies and tools to prevent unauthorized access, use, or loss of sensitive data",
    explanation: "Data loss prevention (DLP) involves using strategies and tools to prevent unauthorized access, use, or loss of sensitive data, protecting it from leaks or breaches."
  },
  {
    question: "What is 'botnet'?",
    options: ["A network of compromised computers controlled by a central attacker", "A type of encryption tool", "A method for securing network traffic", "A type of phishing attack"],
    answer: "A network of compromised computers controlled by a central attacker",
    explanation: "A botnet is a collection of compromised computers that are controlled by an attacker and used to perform malicious activities, such as launching attacks or spreading malware."
  },
  {
    question: "What is 'security token'?",
    options: ["A physical or digital device used to authenticate a user's identity", "A type of encryption algorithm", "A method for managing network traffic", "A technique for securing data"],
    answer: "A physical or digital device used to authenticate a user's identity",
    explanation: "A security token is a device or software used to authenticate a user's identity, often used as part of multi-factor authentication."
  },
  {
    question: "What does 'network traffic analysis' involve?",
    options: ["Monitoring and analyzing network traffic to detect anomalies or threats", "A method for encrypting network data", "A type of firewall rule", "A technique for managing system updates"],
    answer: "Monitoring and analyzing network traffic to detect anomalies or threats",
    explanation: "Network traffic analysis involves examining network traffic patterns to identify unusual behavior or potential security threats."
  },
  {
    question: "What is 'hardware-based security'?",
    options: ["Security measures implemented through physical devices, such as security keys or hardware security modules (HSMs)", "A type of software encryption", "A method for managing network traffic", "A type of malware detection"],
    answer: "Security measures implemented through physical devices, such as security keys or hardware security modules (HSMs)",
    explanation: "Hardware-based security involves using physical devices, like security keys or hardware security modules, to provide secure authentication and protect sensitive data."
  },
  {
    question: "What is 'deception technology'?",
    options: ["Techniques and tools designed to deceive attackers and gather intelligence on their tactics", "A method for encrypting data", "A type of firewall protection", "A technique for managing user access"],
    answer: "Techniques and tools designed to deceive attackers and gather intelligence on their tactics",
    explanation: "Deception technology involves creating decoys or traps to lure and mislead attackers, allowing organizations to detect and analyze their tactics."
  },
  {
    question: "What does 'security audit' involve?",
    options: ["A comprehensive review and assessment of an organization's security practices and controls", "A type of malware detection", "A method for managing network traffic", "A technique for encrypting data"],
    answer: "A comprehensive review and assessment of an organization's security practices and controls",
    explanation: "A security audit involves evaluating an organization's security measures, policies, and controls to ensure they are effective and compliant with standards and regulations."
  },
  {
    question: "What is 'attack vector'?",
    options: ["A method or pathway used by an attacker to exploit a vulnerability", "A type of firewall rule", "A technique for encrypting data", "A method for managing network traffic"],
    answer: "A method or pathway used by an attacker to exploit a vulnerability",
    explanation: "An attack vector is a route or method used by an attacker to exploit a vulnerability and gain unauthorized access to a system or network."
  },
  {
    question: "What is 'digital forensics'?",
    options: ["The process of collecting, analyzing, and preserving digital evidence for legal purposes", "A type of malware detection", "A method for encrypting data", "A technique for managing network traffic"],
    answer: "The process of collecting, analyzing, and preserving digital evidence for legal purposes",
    explanation: "Digital forensics involves gathering, examining, and preserving digital evidence to support legal investigations and proceedings."
  },
  {
    question: "What does 'patch management' involve?",
    options: ["The process of applying updates and fixes to software to address vulnerabilities", "A type of encryption tool", "A method for managing network traffic", "A technique for securing data transmissions"],
    answer: "The process of applying updates and fixes to software to address vulnerabilities",
    explanation: "Patch management involves regularly applying updates and patches to software to fix vulnerabilities and improve security."
  }
];
function getLoginName() {
  return localStorage.getItem('loginName');
}

let currentQuestions = [];
let currentQuestionIndex = 0;
let score = 0;
let timerInterval;
let userAnswers = [];
let currentDifficulty = '';
let username = '';
let correctAnswered = false;

document.querySelector(".next-button").addEventListener("click", function() {
  // Change the background color of the body to a random dark color
  document.body.style.backgroundColor = getRandomDarkColor();
  
  // Optionally change the question text or move to the next question
});

document.querySelector(".skip-button").addEventListener("click", function() {
  // Change the background color of the body to a random dark color
  document.body.style.backgroundColor = getRandomDarkColor();
  
  // Optionally change the question text or move to the next question
});

// Function to generate a random dark color using hex format
function getRandomDarkColor() {
  const letters = "89ABCDEF";  // Use higher hex values for darker colors
  let color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * letters.length)];
  }
  return color;
}


function ToDifficultyPage() {
  document.getElementById('instructionContainer').style.display = 'none';
  document.getElementById('difficultyContainer').style.display = 'block';
}

function startQuiz(difficulty) {
  currentDifficulty = difficulty;

  if (difficulty === 'easy') {
    currentQuestions = shuffleArray(easyQuestions).slice(0, 10);
  } else if (difficulty === 'medium') {
    currentQuestions = shuffleArray(mediumQuestions).slice(0, 10);
  } else if (difficulty === 'hard') {
    currentQuestions = shuffleArray(hardQuestions).slice(0, 10);
  }

  currentQuestionIndex = 0;
  score = 0;
  userAnswers = [];
  correctAnswered = false;

  document.getElementById('difficultyContainer').style.display = 'none';
  document.getElementById('quizContainer').style.display = 'block';
  document.querySelector('footer').style.display = 'none'; // Hide footer

  displayQuestion();
  startTimer();
}

function displayQuestion() {
  const questionContainer = document.getElementById('questionContainer');
  const optionsContainer = document.getElementById('optionsContainer');

  questionContainer.innerHTML = '';
  optionsContainer.innerHTML = '';

  const currentQuestion = currentQuestions[currentQuestionIndex];
  const questionElement = document.createElement('h3');
  questionElement.textContent = currentQuestion.question;
  questionContainer.appendChild(questionElement);

  currentQuestion.options.forEach((option, index) => {
    const optionButton = document.createElement('button');
    optionButton.textContent = option;
    optionButton.addEventListener('click', () => {
      selectOption(index);
    });
    optionsContainer.appendChild(optionButton);
  });

  // Add explanation button
  const explanationButton = document.createElement('button');
  explanationButton.textContent = 'Show Explanation';
  explanationButton.addEventListener('click', () => {
    showExplanation();
  });
  questionContainer.appendChild(explanationButton);

  const progressBarFull = document.getElementById('progressBarFull');
  const progress = ((currentQuestionIndex + 1) / currentQuestions.length) * 100;
  progressBarFull.style.width = `${progress}%`;
}

function selectOption(index) {
  const optionButtons = document.querySelectorAll('#optionsContainer button');
  optionButtons.forEach(button => {
    button.classList.remove('selected');
  });

  const selectedOption = currentQuestions[currentQuestionIndex].options[index];
  const correctAnswer = currentQuestions[currentQuestionIndex].answer;

  userAnswers[currentQuestionIndex] = selectedOption;

  // Increment score if the correct option is selected and it wasn't marked as correct before
  if (selectedOption === correctAnswer && !correctAnswered) {
    score++;
    correctAnswered = true; // Set the flag to true after selecting the correct answer
  }

  // Decrement score if a wrong option is selected after initially selecting the correct answer
  if (selectedOption !== correctAnswer && correctAnswered) {
    score--;
    correctAnswered = false; // Reset the flag as the user selected a wrong answer after the correct one
  }

  const nextButton = document.querySelector('.next-button');
  nextButton.removeAttribute('disabled');

  optionButtons[index].classList.add('selected');
}

function showExplanation() {
  const explanationContainer = document.getElementById('explanationContainer');
  const explanationList = document.getElementById('explanationList');
  explanationList.innerHTML = ''; // Clear previous explanations
  
  answers.forEach((answer) => {
    const question = currentQuestions[answer.questionIndex];
    const listItem = document.createElement('li');
    let explanationText = '';

    // Customize the explanation based on answer status
    if (answer.status === 'correct') {
      explanationText = `<span style="color: green;">Correct: ${question.explanation}</span>`;
    } else if (answer.status === 'incorrect') {
      explanationText = `<span style="color: red;">Incorrect: ${question.explanation}</span>`;
    } else if (answer.status === 'skipped') {
      explanationText = `<span style="color: orange;">Skipped: ${question.explanation}</span>`;
    }

    listItem.innerHTML = explanationText;
    explanationList.appendChild(listItem);
  });

  explanationContainer.style.display = 'block'; // Show the explanation container
}


function nextQuestion() {
  currentQuestionIndex++;
  correctAnswered = false; // Reset the flag for the new question

  if (currentQuestionIndex < currentQuestions.length) {
    stopTimer();
    displayQuestion();
    startTimer();
    const nextButton = document.querySelector('.next-button');
    nextButton.setAttribute('disabled', 'disabled');
  } else {
    stopTimer();
    showScore();
  }
}

function showScore() {
  document.getElementById('quizContainer').style.display = 'none';
  document.getElementById('retryContainer').style.display = 'block';
  document.getElementById('score').textContent = score;

  const saveScoreBtn = document.getElementById('saveScore');
  saveScoreBtn.disabled = false;
}

function retryQuiz() {
  document.getElementById('score').textContent = '';
  document.getElementById('correctAnswersContainer').style.display = 'none';
  const correctAnswersList = document.getElementById('correctAnswersList');
  correctAnswersList.innerHTML = '';

  document.getElementById('highScoresContainer').style.display = 'none';

  startQuiz(currentDifficulty);
  document.getElementById('retryContainer').style.display = 'none';
  document.getElementById('quizContainer').style.display = 'block';
}

function showExplanations() {
  const explanationContainer = document.getElementById('correctAnswersContainer');
  const explanationList = document.getElementById('correctAnswersList');
  explanationList.innerHTML = '';

  currentQuestions.forEach((question, index) => {
    const listItem = document.createElement('li');
    const userAnswer = userAnswers[index];
    let message = `${question.question}: `;

    if (userAnswer === question.answer) {
      message += `${question.answer} (Correct)`;
    } else if (userAnswer === null) {
      message += `${question.answer} (Skipped)`;
    } else {
      message += `${question.answer} (Incorrect)`;
    }

    listItem.innerHTML = `<strong>${message}</strong><br><p>${question.explanation}</p>`;
    explanationList.appendChild(listItem);
  });

  explanationContainer.style.display = 'block';
}

function showHighScores() {
  const highScoresContainer = document.getElementById("highScoresContainer");
  const highScoresList = document.getElementById("highScoresList");
  const highScores = JSON.parse(localStorage.getItem(`${currentDifficulty}HighScores`)) || [];

  // Clear the existing content
  highScoresList.innerHTML = '';

  // Populate the table with high scores
  highScores.forEach(score => {
    const row = document.createElement('tr');
    row.innerHTML = `<td>${score.name}</td><td>${score.score}</td>`;
    highScoresList.appendChild(row);
  });

  // Hide other containers
  document.getElementById('retryContainer').style.display = 'none';
  document.getElementById('correctAnswersContainer').style.display = 'none';
  document.getElementById('quizContainer').style.display = 'none';

  // Show the high scores container
  highScoresContainer.style.display = 'block';
}


function goBack() {
  document.getElementById('highScoresContainer').style.display = 'none';
  document.getElementById('retryContainer').style.display = 'block';
}

function goToDifficultyPage() {
  document.getElementById('score').textContent = '';
  document.getElementById('correctAnswersContainer').style.display = 'none';
  const correctAnswersList = document.getElementById('correctAnswersList');
  correctAnswersList.innerHTML = '';

  document.getElementById('retryContainer').style.display = 'none';
  document.getElementById('difficultyContainer').style.display = 'block';
}

function goToLoginPage() {
  const correctAnswersList = document.getElementById('correctAnswersList');
  correctAnswersList.innerHTML = '';
  document.getElementById('quizContainer').style.display = 'none';
  document.getElementById('retryContainer').style.display = 'none';
  document.getElementById('highScoresContainer').style.display = 'none';
  document.getElementById('loginContainer').style.display = 'block'; // Show the login container or any other relevant content
}

function shuffleArray(array) {
  const shuffledArray = array.slice();
  for (let i = shuffledArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledArray[i], shuffledArray[j]] = [shuffledArray[j], shuffledArray[i]];
  }
  return shuffledArray;
}

const QUESTION_DURATION = 20;

function startTimer() {
  let timeLeft = QUESTION_DURATION;
  document.getElementById('countdown').textContent = timeLeft;

  timerInterval = setInterval(() => {
    timeLeft--;
    document.getElementById('countdown').textContent = timeLeft;

    if (timeLeft === 0) {
      clearInterval(timerInterval);
      nextQuestion();
    }
  }, 1000);
}

function stopTimer() {
  clearInterval(timerInterval);
}

function skipQuestion() {
  stopTimer();

  const selectedOptionIndex = currentQuestions[currentQuestionIndex].options.indexOf(userAnswers[currentQuestionIndex]);
  if (selectedOptionIndex !== -1 && userAnswers[currentQuestionIndex] === currentQuestions[currentQuestionIndex].answer) {
    score--; // Decrement score if the correct option was selected before skipping
  }

  userAnswers[currentQuestionIndex] = null;

  nextQuestion();
}

document.addEventListener('DOMContentLoaded', () => {
  const saveScoreBtn = document.getElementById('saveScore');
  const finalScore = document.getElementById('score');

  if (saveScoreBtn && finalScore) {
    saveScoreBtn.addEventListener('click', () => {
      const mostRecentScore = finalScore.textContent;
      const newScore = {
        score: mostRecentScore,
        name: getLoginName()// Use the stored username
      };

      let highScores = JSON.parse(localStorage.getItem(`${currentDifficulty}HighScores`)) || [];
      highScores.push(newScore);
      highScores.sort((a, b) => b.score - a.score);
      highScores.splice(10);

      localStorage.setItem(`${currentDifficulty}HighScores`, JSON.stringify(highScores));

      saveScoreBtn.disabled = true;
    });
  }
  
});

