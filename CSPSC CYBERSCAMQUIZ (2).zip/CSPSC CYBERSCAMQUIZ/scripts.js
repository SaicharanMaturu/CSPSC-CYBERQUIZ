// Existing code for tips
document.getElementById('addTipBtn').addEventListener('click', addTip);
document.getElementById('showMoreBtn').addEventListener('click', showMoreTips);

function addTip() {
    const newTipInput = document.getElementById('newTipInput');
    const newTip = newTipInput.value.trim();

    if (newTip) {
        const li = document.createElement('li');
        li.textContent = newTip;
        li.style.backgroundColor = "#000"; // Black background for new tips
        li.style.color = "#fff"; // White text for new tips
        document.getElementById('tips-list').appendChild(li);
        newTipInput.value = ''; // Clear input field
    } else {
        alert("Please enter a tip!");
    }
}

function showMoreTips() {
    const tips = [
        "Install antivirus software and keep it updated.",
        "Avoid using public Wi-Fi for online banking or shopping.",
        "Log out of accounts when you’re finished, especially on shared devices.",
        "Be cautious when clicking links in unsolicited emails.",
        "Back up your data regularly to an external drive or cloud storage."
    ];

    const tipsList = document.getElementById('tips-list');
    tips.forEach(tip => {
        const li = document.createElement('li');
        li.textContent = tip;
        li.style.backgroundColor = "#000"; // Black background for new tips
        li.style.color = "#fff"; // White text for new tips
        tipsList.appendChild(li);
    });

    // Disable the button after showing more tips
    document.getElementById('showMoreBtn').disabled = true;
    document.getElementById('showMoreBtn').textContent = 'All Tips Loaded';
}

// Zoom image functionality
// Zoom image functionality
document.querySelectorAll('.image-gallery img').forEach(img => {
    img.addEventListener('click', function () {
        // Toggle zoom effect
        if (this.classList.contains('zoomed')) {
            this.classList.remove('zoomed'); // Remove zoom
        } else {
            // Remove zoom from any other image
            document.querySelectorAll('.zoomed').forEach(zoomedImg => zoomedImg.classList.remove('zoomed'));
            this.classList.add('zoomed'); // Apply zoom to the clicked image
        }
    });
});
