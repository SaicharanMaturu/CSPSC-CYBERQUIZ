const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');
const signInForm = document.getElementById('signInForm');
const signInEmail = document.getElementById('signInEmail');
const signInPassword = document.getElementById('signInPassword');
const signUpForm = document.getElementById('signUpForm');
const signUpName = document.getElementById('signUpName');
const signUpEmail = document.getElementById('signUpEmail');
const signUpPassword = document.getElementById('signUpPassword');

// Predefined default user credentials
const defaultCredentials = {
    name: "Default User",
    email: "user@duronto.com",
    password: "password"
};
function saveLoginName(loginName) {
    localStorage.setItem('loginName', loginName);
  }

// Function to get all stored users from localStorage (initialize with default user if no users exist)
const getStoredUsers = () => {
    let users = localStorage.getItem('users');
    if (!users) {
        // Store the default user if no users exist
        users = [defaultCredentials];
        storeUsers(users);
    } else {
        users = JSON.parse(users);
    }
    return users;
};

// Function to save users array to localStorage
const storeUsers = (users) => {
    localStorage.setItem('users', JSON.stringify(users));
};

// Function to find a user by email
const findUserByEmail = (email) => {
    const users = getStoredUsers();
    return users.find(user => user.email === email);
};

// Sign up form submission
signUpForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // Get the entered name, email, and password
    const name = signUpName.value;
    saveLoginName(name);
    const email = signUpEmail.value;
    const password = signUpPassword.value;

    // Check if the email is already registered
    

    // Add new user to the stored users
    const users = getStoredUsers();
    users.push({ name, email, password });
    storeUsers(users);

    // Clear the signup form fields
    signUpName.value = '';
    signUpEmail.value = '';
    signUpPassword.value = '';

    // Show the sign-in panel
    container.classList.remove("right-panel-active");
    alert("Account created successfully. You can now sign in.");
});

// Toggle to sign-up panel
signUpButton.addEventListener('click', () => {
    container.classList.add("right-panel-active");
});

// Toggle to sign-in panel
signInButton.addEventListener('click', () => {
    container.classList.remove("right-panel-active");
});

// Sign in form submission
signInForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // Get the entered email and password
    const email = signInEmail.value;
    const password = signInPassword.value;

    // Find the user by email
    const user = findUserByEmail(email);

    // Check if the entered credentials match the stored credentials
    if (user && email === user.email && password === user.password) {
        // Successful login
        
        window.location.href = "cyberquiz.html";
    } else {
        // Invalid credentials
        alert("Invalid email or password. Please try again.");
    }
});

// Handle the forgot password scenario
document.getElementById('forgotPassword').addEventListener('click', (e) => {
    e.preventDefault();
    const modal = document.getElementById("forgotPasswordModal");
    modal.style.display = "block"; // Show the modal

    const closeModal = document.getElementsByClassName("close")[0];
    closeModal.onclick = () => {
        modal.style.display = "none"; // Close the modal
    };

    window.onclick = (event) => {
        if (event.target === modal) {
            modal.style.display = "none"; // Close the modal if clicked outside
        }
    };

    document.getElementById('sendResetLink').addEventListener('click', () => {
        const email = document.getElementById("resetEmail").value;

        if (!email) {
            alert("Email is required.");
            return;
        }

        const user = findUserByEmail(email);
        if (user) {
            const newPassword = prompt("Please enter your new password:");
            if (newPassword) {
                user.password = newPassword; // Update the user's password
                const users = getStoredUsers();
                storeUsers(users); // Save updated users to localStorage
                alert("Your password has been reset successfully.");
                modal.style.display = "none"; // Close the modal
            } else {
                alert("Password cannot be empty.");
            }
        } else {
            alert("No account found with this email.");
        }
    });
});
